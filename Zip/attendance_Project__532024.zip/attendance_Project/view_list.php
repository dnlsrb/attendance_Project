<?php include('config/auth/auth_all.php');?>
<?php include('config/Controller/view_list_controller.php'); ?>
<?php include('template/header.php')?>
 
 











<?php include('template/footer.php')?>

 

 