<?php include('config/auth/auth_all.php');?>
<?php include('template/header.php')?>

<div class="container-fluid  d-flex justify-content-center align-items-center " style="height:100vh;">
 <div class="card border-secondary rounded-0" >
 
    <div class="card-body  ">
    <div class="mb-3 row">
    <label for="staticEmail" class="col-sm-3 col-form-label ">User:</label>
    <div class="col-sm-9">
      <input type="text" readonly class="form-control-plaintext" id="staticEmail" value="admin">
    </div>
  </div>
  <div class="mb-3 row">
    <label for="oldpass" class="col-sm-12 col-form-label ">Old Password</label>
    <div class="col-sm-12">
      <input type="password" class="form-control w-100 border-secondary" id="oldpass">
    </div>
  </div>
  <div class="mb-3 row">
    <label for="newpass" class="col-sm-12 col-form-label ">New Password</label>
    <div class="col-sm-12">
      <input type="password" class="form-control w-100 border-secondary" id="newpass">
    </div>
  </div>
  <div class="mb-3 row">
    <label for="confirmpass" class="col-sm-12 col-form-label ">Confirm Password</label>
    <div class="col-sm-12">
      <input type="password" class="form-control w-100 border-secondary" id="confirmpass">
    </div>
  </div>
    </div>
    <div class="card-footer"  >
        <div class="d-flex justify-content-end">
        <input type="submit" class="btn btn-primary" value="submit">
        </div>
         
    </div>
 </div>
</div>



<?php include('template/footer.php')?>