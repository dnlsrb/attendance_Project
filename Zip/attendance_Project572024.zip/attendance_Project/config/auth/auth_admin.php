<?php
 if (isset($_SESSION['role']) && $_SESSION['role'] == 0) {
    include('config/database/db_connect.php');
    
  
} else {
    header("Location: 404.php");
    exit(); // Stop further execution
}
?> 