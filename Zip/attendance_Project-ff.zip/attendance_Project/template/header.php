 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>



    <!-- BOOTSTRAP CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- BOOTSTRAP CDN -->
    <!-- BOOTSTRAP ICON -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!--  -->
      <!-- CSS -->
      <link href="css/style.css" rel="stylesheet">
      <!-- <link rel="stylesheet" href="css/variables.scss"> -->
</head>
<body>
  <!-- BOOTSTRAP JAVASCRIPT -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<?php if(isset($_SESSION['username'])  && isset($_SESSION['password'])): ?>
    
<nav>
<div>  
    <a href="./logout.php">Logout</a>
    <a href="./event_list.php">Event List</a>
   <?php if($_SESSION['role'] == 'admin'):?> <a href="./user_management.php">User Management</a> <?php endif;?>
</div>
 <span>Username: <?php echo htmlspecialchars($_SESSION['username'])?> </span>
 
</nav>
 
<?php endif;?>