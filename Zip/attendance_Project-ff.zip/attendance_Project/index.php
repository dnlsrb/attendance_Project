<?php
session_start();
if (isset($_SESSION['username']) && isset($_SESSION['password'])):
    header('Location: event_List.php');
else:
    ?>
    <?php include ('template/header.php') ?>

    <div class="d-flex justify-content-center align-items-center position-relative"
        style="height:100vh; background-image: linear-gradient(315deg, #ff0203 0%, #1850f5 50%, #04049a 75%);;">
        <?php
        include ('config/db_connect.php');
        if (isset($_GET['error'])) {
            $error = mysqli_real_escape_string($conn, $_GET['error']);
            echo
                ' <div id="failed-alert" class="alert alert-danger position-absolute top-0 end-0 m-3 alert-dismissible fade show" role="alert">'
                . $error . '
                <button type="button"  class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
        }
        mysqli_close($conn);
        ?>
        <script>
            $("#failed-alert").fadeTo(2000, 500).slideUp(500, function () {
                $("#failed-alert").slideUp(500);
            });
        </script>
        <form class="container-fluid bg-white h-50 w-25 rounded-4" action="login.php" method="POST">

            <!-- forms elements -->
            <div class="d-flex flex-column align-items-center py-5">
                <div class="">
                    <h3>Login</h3>
                </div>
                <div class="">
                    <!-- username -->
                    <div class="mb-4 border-bottom">
                        <input type="text" placeholder="Username" name="username" class="border border-0 border-bottom-1"
                            required>
                    </div>
                    <!-- password -->
                    <div class="mb-5">
                        <input type="password" placeholder="Password" name="password"
                            class="border border-0 border-bottom-1" required>
                    </div>
                    <!-- login button -->
                    <div class="">
                        <input type="submit" value="Login" class="rounded-3 w-100 btn btn-primary">
                    </div>
                </div>
            </div>
        </form>
    </div>

    <?php include ('template/footer.php') ?>
<?php endif; ?>