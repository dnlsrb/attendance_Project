 
 <footer class="d-flex flex-wrap  bottom-0 w-100  justify-content-center align-items-center py-3 my-4  ">

 </footer>
</body>
</html>
 