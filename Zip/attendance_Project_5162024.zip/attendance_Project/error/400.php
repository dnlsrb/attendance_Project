
<?php 
$error_code="400 (Bad Request)";
$loc = "../logout.php";
$message = "Client time does not match server time. Please adjust your device's clock";
include('template.php');
?>

 