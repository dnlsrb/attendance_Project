
<?php 
$error_code="404 (Not Found)";
$loc = "../index.php";
$message = "The server cannot locate the requested resource.";
include('template.php');

?>