 
 <footer class="d-flex flex-wrap  bottom-0 w-100  justify-content-center align-items-center py-3 my-4  ">

 </footer>
</body>
</html>
 
<!-- 
ATTENDANCE MANAGEMENT SYSTEM PROJECT:
Robles Jr, Danilo
Lancero, Tom
Aguilar, Joseph Marvin
Cesista, Cristian John
Moncera, Edmar
Moncera, Edward
(DURING INTERNSHIP AT GX INTERNATIONAL INC 2024) 
-->