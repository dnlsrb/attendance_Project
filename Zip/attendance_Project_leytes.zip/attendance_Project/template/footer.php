 <footer class="d-flex flex-wrap   bottom-0 w-100  justify-content-center align-items-center py-3 my-4 border-top">
 
 
       
      <div class="text-center"> 
      <!-- <a href="/" class="mb-3 me-2 mb-md-0 text-body-secondary text-decoration-none lh-1">
      <img src="storage/logo2.png" alt="GXII" width="30"   >
      </a> -->
      <figure>
  <blockquote class="blockquote">
   <p> "A vision to seek for options so that quality medical treatment may not have to be expensive"  </p>
</blockquote>
    <figcaption class="blockquote-footer">
     Rodolfo I. Gracia
  </figcaption>
</figure>
</div>
    

   
  </footer>
</body>
</html>
 