
<?php 
$error_code= "403 (Forbidden)";
$loc = "../index";
$message = "You don't have permission to access this resource.";
include('template.php');

?>