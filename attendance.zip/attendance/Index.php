<?php session_start();?>
<html>
<head>

<style>
body
{ 
background-image: url('images2.jpg');
background-repeat: no-repeat;
background-position: left;
}
</style>
</head>

<frameset rows="15%,*,5%" noresize="true" bordercolor="white" border="1">
	<frameset rows="*,1%" bordercolor="#e31f2d" border="1">
	<frame src="header.php" scrolling="no" />
	<frame src="blank.php" /></frameset>
	<frameset cols="50%,50%" bordercolor="#bcbfcc" border="1">
		<frame src="time.php" scrolling="no" />
		<frame src="frame.php" scrolling="yes" /><frame src="UntitledFrame-3"></frameset>
  <frame src="footer.php" scrolling="no" />
</frameset><noframes></noframes>
</html>


