<html>
<head>
<title></title>
<style>
body
{ 
	background-image: url('images2.jpg');
	background-repeat: no-repeat;
	background-position: right;
}
font
{
	font-size: 14px;
	font-weight:bold;
	font-family: "Open Sans";
	color: #0a1689;
}
#copy
{
	font-family: "Open Sans";
	font-size: x-small;
}

</style>
</head>
<body oncontextmenu="return false;">
<div style="margin-top: -4px; text-align: center;">
<font>"A vision to seek for options so that quality medical treatment may not have to be expensive" - Rodolfo I. Gracia</font>
</div>

<div id="copy" align="center">GX INTERNATIONAL, INC. &copy; 2023</div>
</body>
</html>