<html oncontextmenu="return false;">
<head>
<title></title>
</head>

<body oncontextmenu="return false;">
</body>
</html>