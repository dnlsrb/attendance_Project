<?php 
session_start();
include ('BarConnection.php');
mysqli_select_db($connection,$database);
date_default_timezone_set("Asia/Singapore");
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="instascan.js"></script>

<title>UPPGH-Pedia</title>
<style>
input[id="date"]{ font-size: 15px; }
font.text
{
    font-family: "Open Sans";
    color: #000000;
	font-size: 16px;
}
fieldset
{
	border-style:solid;
	background: #eee;
	width: 100%;
	-webkit-border-radius: 0.5em;
	-o-border-radius: 0.5em;
	margin-top:20px;
	margin-left:-10px;
}
time
{
	letter-spacing: 10px;
	color: #09F;
	font-size: 85px;
	text-shadow: 1px 1px 0 #666;
	top: auto;
	font-family: "Arial Narrow";
	font-weight: bold;
	word-spacing: 0px;
}
legend{	font-size: 15px;}
date
{
    font-family: "Open Sans";
    color: #000000;
    font-size:24px;
	text-align:center;
	
}
input.text
{
    width: 100%;
	height: 60px;
	font-size: 20px;
	text-align:center;
	font-weight: bolder;
	color: #009;
}
body {
	margin: 10px, 10px, 10px, 10px;
	background-image: url(pedia.jpg);
	background-repeat: repeat;
}
body.image{
	opacity:0.4;
}

body_alert {
  font-family: "Open Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", Helvetica, Arial, sans-serif; 
}





</style>
<script language="javascript">

function isNumberKey(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode
	if (charCode > 31 && (charCode < 48 || charCode > 57))
	return false;
	
	return true;
}
function startTime()
{
	var today=new Date();
	var h=today.getHours();
	var m=today.getMinutes();
	var s=today.getSeconds();

	
	var time_ampm = today.toLocaleTimeString();
	m=checkTime(m);
	s=checkTime(s);
	
	if(h>12)
	{
		h=h-12;
	}
	document.getElementById('time').innerHTML=time_ampm;
	document.getElementById('time').innerHTML=time_ampm;
	t=setTimeout(function(){startTime()},500);
}
function checkTime(i)
{
	if (i<10)
	{
	  i="0" + i;
	}
	return i;
}


</script>
</head>
<?php
if(isset($_POST['name--']))
{
	$date = date("F j, Y");
	$var ="";
	$selectSQL='SELECT * FROM attendancetbl WHERE name="'.$_POST['name'].'" ORDER BY id DESC';
	$R = mysqli_query($connection,$selectSQL) or die(mysqli_error());
	$row = mysqli_fetch_array($R);
	
	
	if(mysqli_num_rows($R))
	{
		if($row['timeout']=="")
		{
			$updateSQL = "UPDATE attendancetbl SET timeout='".date("M d, Y h:i:s A")."' WHERE id='".$row['id']."'";
			$result = mysqli_query($connection,$updateSQL) or die(mysql_error());
			?>
				<script>
					var left = (screen.width - 500) / 2;  // Calculate the left position
					var top = (screen.height - 100) / 2;  // Calculate the top position
					var w = window.open('', '', 'width=500, height=100, left=' + left + ', top=' + top);
					w.document.write('GOODBYE, Thank you for Attending!')
					w.focus()
					setTimeout(function() {w.close();}, 3000)
				</script>
			<?php
		}
		else
		{
		
				
			
			$insertSQL = "INSERT INTO attendancetbl (name,timein) VALUES ('".$_POST['name']."','".date("M d, Y h:i:s A")."')";
			$result = mysqli_query($connection,$insertSQL) or die(mysql_error());
			?>
				<script>
					var left = (screen.width - 500) / 2;  // Calculate the left position
					var top = (screen.height - 100) / 2;  // Calculate the top position
					var w = window.open('', '', 'width=500, height=100, left=' + left + ', top=' + top);
					w.document.write('WELCOME!, your attendance is successfully recorded')
					w.focus()
					setTimeout(function() {w.close();}, 3000)
				</script>
			<?php
			
		}
	}
	else
	{
			
		$insertSQL = "INSERT INTO attendancetbl (name,timein) VALUES ('".$_POST['name']."','".date("M d, Y h:i:s A")."')";
		$result = mysqli_query($connection,$insertSQL) or die(mysql_error());
				?>
				<script>
					var left = (screen.width - 500) / 2;  // Calculate the left position
					var top = (screen.height - 100) / 2;  // Calculate the top position
					var w = window.open('', '', 'width=500, height=100, left=' + left + ', top=' + top);
					w.document.write('WELCOME!, your attendance is successfully recorded')
					w.focus()
					setTimeout(function() {w.close();}, 3000)
				</script>
			<?php
		
	
	}

}
?>
<body onLoad="startTime()" >
<table width="80%" align="center" cellpadding="0" cellspacing="0" >
  <tr>
    <td>
<form method="post" id="form" name="form"  action="time.php">
<center>
<fieldset>

<table border="0" cellpadding="5" cellspacing="0">
<tr>
	<td>
	<center>
	<strong><time id="time">00:00:00</time>
	  
    <font class="text">

    <hr size="1px">
	<?php
		echo "Today is ".date("l F d, Y");
	?>

	</font>
	</strong>
	</center>
    <hr size="1px">  
    </td>
</tr>
<br />

<tr>

	<td align="center"><font face="Arial Narrow"><strong>TIME IN / TIME OUT</strong></font></td>
	
	  
	</span></td>
</tr>
<tr>
<td>
<input name="name" id="name" type="text" autofocus required class="text" placeholder="Participant" autocomplete="off" onBlur="required"  value="" maxlength="50"/>


</td>

</tr>


</table>
<br />
</fieldset>
</br>

<video id="preview" width="100%" height="50%" style="border-radius:20px;"></video>

<script>
	let scanner = new Instascan.Scanner({ video: document.getElementById('preview')});
	Instascan.Camera.getCameras().then(function(cameras){
		if(cameras.length > 0){
			scanner.start(cameras[0]);
		}else{
			alert('No se encontraron cámaras');
		}

	}).catch(function(e){
		console.error(e);
	});

	scanner.addListener('scan',function(c){
		document.getElementById('name').value=c;
		document.getElementById('form').submit();
		
		//document.input['submit'].submit();
	});
</script>
</center>
<!--input type="submit" name="submit" id="submit" value="" hidden="hidden" class="buttonCustomized cursorShowPointer" /-->
</form>
</td>
</tr>
  <tr>
    <td></td>
  </tr>
</table>
</body>
</html>