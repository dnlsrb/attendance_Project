<?php
$hostname = "localhost";
$username = "root";
$password = "PfNgB@y@n";
$database = "pedia_attendance";
$connection = mysqli_connect($hostname, $username, $password)or die("Unable to connect to MySQL");
?>


