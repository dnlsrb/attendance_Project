<html>
<head>
<title></title>
<style>
opa
{
	opacity:0.2;
}
font.head
{
    font-family: "Arial Narrow";
	font-weight:bold;
    color: #00C;
	letter-spacing: 3px;
}
div
{
	position: absolute;
}
body {
	background-image: url(bgheader.jpg);
	background-position: center center;
	background-repeat: no-repeat;
	background-size: cover;
	
	margin-top: 0px;
}
</style>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>

<body>

</body>
</html>