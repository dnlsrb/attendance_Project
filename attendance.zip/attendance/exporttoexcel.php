
<?php session_start();include("BarConnection.php");
$filename = "PGH Attendance Record as of \t".date("M-d-Y");
header("Content-Type: application/xls");    
header("Content-Disposition: attachment; filename=$filename.xls"); ?>
<html>
<meta http-equiv="refresh" content="3">

<style>
.table2
{
	font-family: "Arial Narrow";
	font-size: 14px;
	border:thin #CCC;
	border-collapse:collapse;
	
}
td
{
	border-bottom: #CCC solid thin;
}
body {
	font-family: "Arial Narrow";
	margin-left: 0px;
	margin-top: 10px;
	margin-right: 0px;
	margin-bottom: 0px;
}
</style>
<body >
<?php
$date = date("F j, Y");
mysqli_select_db($connection, $database);
$searchSQL = 'SELECT * FROM attendancetbl  ORDER BY id DESC';
$result = mysqli_query($connection,$searchSQL) or die(mysqli_error());

if(mysqli_num_rows($result)>0)
{
?>
<table width="50%" align="center" cellpadding="5" class="table2" >
<th height="35" colspan="3" bgcolor="#CCCCFF">PRESENT TODAY</th>
<tr>
<td><center><strong>Name</strong></center></td>
<td width="15%"><center>
  <strong>IN</strong>
</center></td>

<td width="15%"><center>
  <strong>OUT</strong>
</center></td>

<?php
	while($row = mysqli_fetch_array($result))
	{

?>
	<tr style="font-weight:bold">
	
	<td width="34%"><strong><?php echo $row['name']; ?></strong></td>
	<td width="33%" style="color:blue"><center><?php echo $row['timein']; ?></center></td>
	<td width="33%" style="color:red"><center><?php echo $row['timeout']; ?></center></td>
	
	</tr>
<?php
		
	}
}
else
{
?>
	<strong><font face="Arial">No activity log yet</font></strong>
<?php
}
?>
</table>
</body>
</html>